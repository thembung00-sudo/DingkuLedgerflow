# LedgerFlow – Android app (WebView wrapper)

Your HTML lives in app/src/main/assets/index.html (unchanged).

## Get the APK (no installs needed)
1. Create a free GitHub repo, upload everything in this folder (keep the .github folder).
2. Open the repo's Actions tab -> "Build APK" -> Run workflow (it also runs on every push).
3. When it finishes (~3-5 min), download the "LedgerFlow-apk" artifact -> unzip -> app-debug.apk.
4. Copy to your phone, open it, allow "install unknown apps" when asked.

## Or build locally
Open this folder in Android Studio and run Build > Build APK(s),
or with Gradle 8.9 + JDK 17 + Android SDK 34: gradle assembleDebug
Output: app/build/outputs/apk/debug/app-debug.apk

Exports (CSV/Excel) are saved to the phone's Downloads folder. Requires Android 10+.
